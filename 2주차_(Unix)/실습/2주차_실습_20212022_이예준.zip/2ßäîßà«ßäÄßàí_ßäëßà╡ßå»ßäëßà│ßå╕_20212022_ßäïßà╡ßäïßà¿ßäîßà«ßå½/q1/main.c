#include <stdio.h>

extern int dog();
extern int blackcow();
extern int turtle();

int main(){

  dog();
  blackcow();
  turtle();
  
  return 0;
}