#include <stdio.h>

int turtle(){
  printf("turtle's leg_count is 4\n");
  return 0;
}