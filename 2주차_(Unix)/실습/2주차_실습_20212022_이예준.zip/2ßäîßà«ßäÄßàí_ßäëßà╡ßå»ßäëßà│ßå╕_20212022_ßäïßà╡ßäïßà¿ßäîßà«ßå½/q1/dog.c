#include <stdio.h>

int dog(){
  printf("dog's leg_count is 4\n");
  return 0;
}