#include <stdio.h>

int blackcow(){
  printf("blackcow's leg_count is 4\n");
  return 0;
}