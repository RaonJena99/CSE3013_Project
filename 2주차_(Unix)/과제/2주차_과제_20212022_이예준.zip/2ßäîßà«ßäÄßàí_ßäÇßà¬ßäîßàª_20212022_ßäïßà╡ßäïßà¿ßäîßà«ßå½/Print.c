#include "Header.h"

void Print(){
  for(int i=0;i<10;i++) printf("%d ",arr[i]); //계산된 배열 출력
  printf("\n");
}