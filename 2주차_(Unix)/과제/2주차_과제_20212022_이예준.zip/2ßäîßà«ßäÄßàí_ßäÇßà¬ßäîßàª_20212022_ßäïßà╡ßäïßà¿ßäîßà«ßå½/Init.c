#include "Header.h"

void Init(){
  for(int i=0;i<10;i++) arr[i]=0; //배열 초기화
}